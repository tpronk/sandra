# *********************
# *** SANDRA Jasmin1Decoder

# Decodes JASMIN1 data stored in a LOTUS results file into trial data

# Create sandra namespace if not exists
if( !exists( "sandra" ) ) { 
  sandra = list();
}

sandra$Jasmin1Decoder = list(
  # Find an event with source evSource, type evType, search in logs
  # return index of first matching row at or beyond startPos
  find_event = function( logs, start_pos, evSource = NULL, evType = NULL, evName = NULL )
  {
    matches = rep( T, nrow( logs ) );
    
    # Filter on source, type, and name
    if( !is.null( evSource ) )
    {
      matches = matches &  logs[ ,"source" ] == evSource;
    }
    if( !is.null( evType ) )
    {
      matches = matches &  logs[ ,"type" ] == evType;
    }	
    if( !is.null( evName ) )
    {
      matches = matches &  logs[ ,"name" ] == evName;
    }	
    
    match_events = which( matches );
    if( length( match_events ) == 0 )
    {
      return( NULL );
    }
    match_pos    = match_events[ match_events >= start_pos ];
    if( length( match_pos ) == 0 )
    {
      return( NULL );
    }	
    
    return( min( match_pos ) );
  },
  
  find_next_event = function( events, logs, start_index )
  {
    indexes = c();
    for( event in events )
    {
      index = find_event( 
        logs, 
        start_index, 
        evSource = event[[ "source" ]], 
        evType   = event[[ "type"   ]],
        evName   = event[[ "name"   ]]
      );
      indexes = c( indexes, index );
    }
    if( is.null( indexes ) )
    {
      return( NULL );
    }
    return( min( indexes ) );
  },
  
  # Segment data into events
  run_mop = function( events, logs, output, first_pos, last_pos )
  {
    start_index = first_pos;
    while( !is.null( start_index ) && start_index <= last_pos )
    {
      # Find next event
      start_index = find_next_event( 
        events[[ "start" ]],
        logs, 
        start_index
      );
      
      if( !is.null( start_index )  )
      {
        stop_index = find_next_event( 
          events[[ "stop" ]],
          logs, 
          start_index + 1
        );			
        
        # Only process if seq numbers are different
        if( !is.null( stop_index ) && logs[ start_index, "sequence_number" ] != logs[ stop_index, "sequence_number" ] )
        {
          output = events[[ "callback" ]](
            logs,
            start_index,
            stop_index, 
            output,
            events[[ "name" ]]
          );
        }
        
        if( is.null( stop_index )  )
        {
          start_index = NULL;
        } else {
          start_index = stop_index;
        }
      }
    }
    
    return( output );
  },

  decode = function( 
    input, 
    participationID = c( "UserID" ),
    colRunID = "RunID",
    colName   = "Name",
    colValue  = "Value"    
  ) {
    # Construct colUserID = "ParticipationID" as combination of colsParticipation
    colUserID = "ParticipationID";
    input[ ,"ParticipationID" ] = apply(
      input,
      1,
      function( row ) {
        return(
          paste( row[ participationID ], collapse = "_" )
        );
      }
    ); 
    
    # Check if source_file was properly formatted
    if( length( names( input ) ) == 1 ) {
      print( "sandra$Jasmin1Decoder$decode. Warning: I found one variable name at the first row. Are you sure the is tab (\\t) separated?")
    }
    
    # cols_lotus are all columns except RunID, Name, and Value
    cols_lotus = names( input );
    for( i in c( colRunID, colName, colValue ) )
    {
      col_drop = which( cols_lotus == i );
      if( length( col_drop ) > 0 )
      {
        cols_lotus = cols_lotus[ -col_drop ];
      }
    }
    
    # Custom data encoded in task_start event
    i = which( input[ ,colName ] == "task_start" )[1];
    value = fromJSON( input[ i, colValue ] );
    cols_custom = names( value );
    
    # default columns in metadata
    cols_metadata = c( cols_lotus, cols_custom, "run_from", "run_to", "set_id", "lotus_says", "event_count", "sequence_report" );
    metadata = data.frame( matrix( nrow = 0, ncol = length( cols_metadata ) ) );
    names( metadata ) = cols_metadata;
    
    # Sort by colUserID, then by colRunID 
    input = input[ with( input, order( input[ ,colUserID ], input[, colRunID ] ) ), ]
    
    
    
    
    # Show data without value column
    # input[ -which( names( input ) == colValue ) ];
    
    # Indexes of task_start and task_done
    indexes_task_start = which( input[ ,colName ] == "task_start" )
    indexes_task_done  = which( input[ ,colName ] == "task_start" | input[ ,colName ] == "task_done" | input[ ,colName ] == "task_error" )
    
    # Build up sets
    sets = list();
    # Find matching task_done for each task_start
    for( i in indexes_task_start )
    {
      # Assume a matching done
      match_found = T;
      
      later_start = indexes_task_start[ indexes_task_start > i ];
      later_done  = indexes_task_done[  indexes_task_done  > i ];
      
      # Is there a done?
      if( length( later_done ) == 0 )
      {
        next_done = nrow( input ) + 1;
      } else {
        # Yes, find next one
        next_done = min( later_done );
      }
      
      # If matching done, add to set
      if( match_found )
      {
        sets[[ length( sets ) + 1 ]] = c( i, next_done );
      }
    }
    
    
    # Setup interim and output directory
    dir_interim = conc( dir_data, interim_folder );
    dir.create( dir_interim, showWarning = FALSE );
    filename = conc( interim_folder, "/", source_file );
    
    dir_output = conc( dir_data, output_folder );
    dir.create( dir_output, showWarning = FALSE );
    
    report( conc( "process_lotus. ", length( sets ), " sets found" ) );    
  }
);
